"use client";

import { useTranslations } from "next-intl";
import {
  UsersRound,
  Calendar,
  Code2,
  Video,
  CheckCircle,
  RotateCcw,
} from "lucide-react";

interface ProcessStepProps {
  icon: React.ReactNode;
  number: number;
  title: string;
  description: string;
}

function ProcessStep({ icon, number, title, description }: ProcessStepProps) {
  return (
    <div className="flex gap-6">
      <div className="flex-shrink-0">
        <div className="relative">
          <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/20 flex items-center justify-center">
            {icon}
          </div>
          <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
            {number}
          </div>
        </div>
      </div>
      <div>
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
          {title}
        </h3>
        <p className="text-gray-600 dark:text-gray-400">{description}</p>
      </div>
    </div>
  );
}

export default function DevelopmentProcess() {
  const t = useTranslations("teamBuilding");

  const steps = [
    {
      id: "assembleTeam",
      icon: <UsersRound className="w-6 h-6 text-purple-600 dark:text-purple-400" />,
      title: t("steps.assembleTeam.title"),
      description: t("steps.assembleTeam.description"),
    },
    {
      id: "sprintPlanning",
      icon: <Calendar className="w-6 h-6 text-purple-600 dark:text-purple-400" />,
      title: t("steps.sprintPlanning.title"),
      description: t("steps.sprintPlanning.description"),
    },
    {
      id: "techArchitecture",
      icon: <Code2 className="w-6 h-6 text-purple-600 dark:text-purple-400" />,
      title: t("steps.techArchitecture.title"),
      description: t("steps.techArchitecture.description"),
    },
    {
      id: "standups",
      icon: <Video className="w-6 h-6 text-purple-600 dark:text-purple-400" />,
      title: t("steps.standups.title"),
      description: t("steps.standups.description"),
    },
    {
      id: "codeReviews",
      icon: <CheckCircle className="w-6 h-6 text-purple-600 dark:text-purple-400" />,
      title: t("steps.codeReviews.title"),
      description: t("steps.codeReviews.description"),
    },
    {
      id: "iterative",
      icon: <RotateCcw className="w-6 h-6 text-purple-600 dark:text-purple-400" />,
      title: t("steps.iterative.title"),
      description: t("steps.iterative.description"),
    },
  ];

  return (
    <section id="process" className="py-16 md:py-24">
      <div className="flex flex-col items-center mb-16">
        <div className="h-1 w-16 bg-gradient-to-r from-pink-500 to-purple-800 rounded-full mb-6" />
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white">
          {t("title")}
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {steps.map((step, index) => (
          <ProcessStep
            key={step.id}
            icon={step.icon}
            number={index + 1}
            title={step.title}
            description={step.description}
          />
        ))}
      </div>
    </section>
  );
} 