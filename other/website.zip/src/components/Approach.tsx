"use client";

import { useTranslations } from "next-intl";
import { Shield, Code, Users, Lightbulb, CheckCircle, Lock } from "lucide-react";

interface ApproachCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  colorClass: string;
}

function ApproachCard({ icon, title, description, colorClass }: ApproachCardProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-100 dark:border-gray-700 p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-center gap-4 mb-4"> {/* 包裹 icon 和 title，并使用 flex */}
        <div className={`w-12 h-12 rounded-lg ${colorClass} flex items-center justify-center`}>
          {icon}
        </div>
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-0"> {/* 修改 marginBottom 为 0 */}
          {title}
        </h3>
      </div>
      <p className="text-gray-600 dark:text-gray-400">
        {description}
      </p>
    </div>
  );
}
export default function Approach() {
  const t = useTranslations("approach");

  const approaches = [
    {
      id: "uxDriven",
      icon: <Lightbulb className="w-6 h-6 text-white" />,
      title: t("uxDriven.title"),
      description: t("uxDriven.description"),
      colorClass: "bg-blue-600",
    },
    {
      id: "sharedUnderstanding",
      icon: <Users className="w-6 h-6 text-white" />,
      title: t("sharedUnderstanding.title"),
      description: t("sharedUnderstanding.description"),
      colorClass: "bg-cyan-500",
    },
    {
      id: "security",
      icon: <Shield className="w-6 h-6 text-white" />,
      title: t("security.title"),
      description: t("security.description"),
      colorClass: "bg-green-500",
    },
    {
      id: "qa",
      icon: <CheckCircle className="w-6 h-6 text-white" />,
      title: t("qa.title"),
      description: t("qa.description"),
      colorClass: "bg-purple-600",
    },
    {
      id: "codeReview",
      icon: <Code className="w-6 h-6 text-white" />,
      title: t("codeReview.title"),
      description: t("codeReview.description"),
      colorClass: "bg-yellow-500",
    },
    {
      id: "expertise",
      icon: <Lock className="w-6 h-6 text-white" />,
      title: t("expertise.title"),
      description: t("expertise.description"),
      colorClass: "bg-pink-500",
    },
  ];

  return (
    <section id="how-it-works" className="py-16 md:py-24">
      <div className="text-center mb-16">
        <div className="flex flex-col items-center mb-6">
          <div className="h-1 w-16 bg-gradient-to-r from-pink-500 to-purple-800 rounded-full mb-6" />
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white">
            {t("title")}
          </h2>
        </div>
        <h3 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
          {t("developmentTitle")}
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
        {approaches.map((approach) => (
          <ApproachCard
            key={approach.id}
            icon={approach.icon}
            title={approach.title}
            description={approach.description}
            colorClass={approach.colorClass}
          />
        ))}
      </div>
    </section>
  );
}