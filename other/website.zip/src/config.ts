export const locales = ['en', 'zh'];
export const defaultLocale = 'zh'; 