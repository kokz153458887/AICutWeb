"use client";

import { useLanguage } from "@/context/LanguageContext";
import Image from "next/image";
import logger from "@/utils/logger";

interface TeamMember {
  id: string;
  name: string;
  title: string;
  description: string;
  image: string;
  social?: {
    twitter?: string;
    linkedin?: string;
    github?: string;
  };
}

function TeamMemberCard({ member }: { member: TeamMember }) {
  logger.debug("member: ", member);
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 dark:border-gray-700">
      <div className="p-6">
        <div className="flex items-center mb-4"> 
          <Image src={member.image} alt={member.name} width={60} height={60} className="rounded-full" />
          <div className="ml-4 flex justify-center flex-col">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">
              {member.name}
            </h3>
            <p className="text-purple-600 dark:text-purple-400 font-medium">
              {member.title}
            </p>
          </div>
        </div>

        <p className="text-gray-700 dark:text-gray-300 mb-4 line-clamp-3">
          {member.description}
        </p>
      </div>
    </div>
  );
}

export default function Team() {
  const { messages } = useLanguage();
  const t = messages.team || {};

  const members = (t.members || []) as unknown as TeamMember[];
  logger.debug("[Team] members: ", members);
  return (
    <section id="team" className="py-16 md:py-24">
      <div className="text-center mb-16">
        <h2 className="text-3xl md:text-4xl font-bold text-black dark:text-white mb-4">
          {t.title}
        </h2>
        <p className="max-w-3xl mx-auto text-gray-700 dark:text-gray-300">
          {t.description}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {members.map((member, index) => (
          <TeamMemberCard key={index } member={member} />
        ))}
      </div>
    </section>
  );
} 