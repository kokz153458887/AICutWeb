"use client";

import { useTranslations } from "next-intl";
import Link from "next/link";
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin, Github } from "lucide-react";

export default function Footer() {
  const t = useTranslations("footer");
  const navT = useTranslations("nav");

  const navItems = [
    { key: "aboutUs", label: navT("aboutUs"), href: "#about-us" },
    { key: "services", label: navT("services"), href: "#services" },
    { key: "caseStudies", label: navT("caseStudies"), href: "#case-studies" },
    { key: "team", label: navT("team"), href: "#team" },
    { key: "howItWorks", label: navT("howItWorks"), href: "#how-it-works" },
    { key: "hire", label: navT("hire"), href: "#hire" },
  ];

  return (
    <footer className="bg-gray-50 dark:bg-gray-900 pt-16 pb-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <Link
                href="/"
                className="flex items-center text-2xl font-bold bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-transparent bg-clip-text"
              >
                CodeDream
              </Link>
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {t("about")}
            </p>
            <div className="flex space-x-4">
              <a
                href="#"
                className="text-gray-400 hover:text-blue-600 dark:hover:text-blue-400"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-blue-400 dark:hover:text-blue-400"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-pink-600 dark:hover:text-pink-400"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-blue-700 dark:hover:text-blue-400"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-gray-800 dark:hover:text-white"
              >
                <Github className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {t("links")}
            </h3>
            <ul className="space-y-3">
              {navItems.map((item) => (
                <li key={item.key}>
                  <Link
                    href={item.href}
                    className="text-gray-600 dark:text-gray-400 hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Us */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {t("contactUs")}
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-gray-500 dark:text-gray-400 flex-shrink-0 mt-0.5" />
                <span className="text-gray-600 dark:text-gray-400">
                  123 Innovation Street, Tech City, 10001
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-gray-500 dark:text-gray-400 flex-shrink-0" />
                <span className="text-gray-600 dark:text-gray-400">
                  {t("phone")}
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gray-500 dark:text-gray-400 flex-shrink-0" />
                <span className="text-gray-600 dark:text-gray-400">
                  contact@coderdream.com
                </span>
              </li>
            </ul>
          </div>

          {/* Newsletter (placeholder) */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Newsletter
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Subscribe to our newsletter to get latest updates.
            </p>
            <div className="flex">
              <input
                type="email"
                placeholder="Your email"
                className="p-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-l-md w-full focus:outline-none focus:ring-2 focus:ring-purple-600 dark:focus:ring-purple-400"
              />
              <button className="bg-purple-600 hover:bg-purple-700 text-white px-4 rounded-r-md">
                Send
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 dark:border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-500 dark:text-gray-400 text-sm">
            {t("copyright")}
          </p>
        </div>
      </div>
    </footer>
  );
} 