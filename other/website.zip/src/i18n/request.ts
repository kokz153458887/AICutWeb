import {getRequestConfig} from 'next-intl/server';
import {notFound} from 'next/navigation';
import {locales} from '../config';

export default getRequestConfig(async ({locale}) => {
  // 验证传入的locale参数是否有效
  if (!locales.includes(locale as string)) {
    notFound();
  }

  const typedLocale: string = locale as string;

  try {
    return {
      messages: (await import(`../messages/${typedLocale}.json`)).default,
      locale: typedLocale
    };
  } catch (error) {
    console.error(`Error loading messages for locale ${typedLocale}:`, error);
    notFound();
  }
});