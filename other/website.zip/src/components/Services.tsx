"use client";

import { Code, Smartphone, FileText } from "lucide-react";
import { useTranslations } from "next-intl";
import { useState } from "react";

// 服务卡片组件
function ServiceCard({
  title,
  description,
  icon,
  isActive,
  onClick,
}: {
  title: string;
  description: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <div
      className={`rounded-lg p-6 transition-all duration-300 ${
        isActive
          ? "bg-purple-600 text-white shadow-lg shadow-purple-200 dark:shadow-purple-900/20"
          : "bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 border border-gray-100 dark:border-gray-700"
      } cursor-pointer`}
      onClick={onClick}
    >
      <div className="flex items-center mb-4">
        <div
          className={`w-12 h-12 rounded-full flex items-center justify-center ${
            isActive ? "bg-white/10" : "bg-purple-100 dark:bg-purple-900/20"
          }`}
        >
          {icon}
        </div>
        <h3 className="text-xl font-semibold ml-3">{title}</h3>
      </div>
      <p
        className={
          isActive ? "text-white/80" : "text-gray-700 dark:text-gray-400"
        }
      >
        {description}
      </p>
    </div>
  );
}

export default function Services() {
  const t = useTranslations("services");
  const [activeIndex, setActiveIndex] = useState(-1); // Web Development is active by default

  const services = [
    {
      id: "mobileDev",
      title: t('mobileDev.title'),
      description: t('mobileDev.description'),
      icon: (
        <Smartphone
          className={`w-6 h-6 ${
            activeIndex === 0 ? "text-white" : "text-purple-600 dark:text-purple-400"
          }`}
        />
      ),
    },
    {
      id: "softwareTesting",
      title: t('softwareTesting.title'),
      description: t('softwareTesting.description'),
      icon: (
        <FileText
          className={`w-6 h-6 ${
            activeIndex === 1 ? "text-white" : "text-purple-600 dark:text-purple-400"
          }`}
        />
      ),
    },
    {
      id: "webDev",
      title: t('webDev.title'),
      description: t('webDev.description'),
      icon: (
        <Code
          className={`w-6 h-6 ${
            activeIndex === 2 ? "text-white" : "text-purple-600 dark:text-purple-400"
          }`}
        />
      ),
    },
  ];

  return (
    <section id="services" className="py-16 md:py-24 rounded-3xl">
      <div className="text-center mb-16">
        <h2 className="text-3xl md:text-4xl font-bold text-black dark:text-white mb-6">
          {t('title')}
        </h2>
        <div className="flex justify-center space-x-2 mt-4">
          {[0, 1, 2, 3, 4].map((_, i) => (
            <div
              key={i}
              className={`w-2 h-2 rounded-full ${
                i === 0
                  ? "bg-purple-600"
                  : "bg-gray-300 dark:bg-gray-700"
              }`}
            />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {services.map((service, index) => (
          <ServiceCard
            key={service.id}
            title={service.title}
            description={service.description}
            icon={service.icon}
            isActive={index === activeIndex}
            onClick={() => setActiveIndex(index)}
          />
        ))}
      </div>
    </section>
  );
} 