"use client";

import { useTranslations } from "next-intl";

export default function TechStack() {
  const t = useTranslations("techStack");

  const techStacks = [
    {
      id: "frontend",
      title: t("categories.frontend"),
      tools: [
        { name: "React", logo: "/images/tech/react.svg" },
        { name: "Next.js", logo: "/images/tech/nextjs.svg" },
        { name: "TypeScript", logo: "/images/tech/typescript.svg" },
        { name: "Vue.js", logo: "/images/tech/vue.svg" },
        { name: "Angular", logo: "/images/tech/angular.svg" },
      ],
    },
    {
      id: "backend",
      title: t("categories.backend"),
      tools: [
        { name: "Node.js", logo: "/images/tech/nodejs.svg" },
        { name: "Express", logo: "/images/tech/express.svg" },
        { name: "Django", logo: "/images/tech/django.svg" },
        { name: "Ruby on Rails", logo: "/images/tech/rails.svg" },
        { name: "Spring Boot", logo: "/images/tech/spring.svg" },
      ],
    },
    {
      id: "databases",
      title: t("categories.databases"),
      tools: [
        { name: "MongoDB", logo: "/images/tech/mongodb.svg" },
        { name: "PostgreSQL", logo: "/images/tech/postgresql.svg" },
        { name: "MySQL", logo: "/images/tech/mysql.svg" },
        { name: "Redis", logo: "/images/tech/redis.svg" },
        { name: "Firebase", logo: "/images/tech/firebase.svg" },
      ],
    },
    {
      id: "devops",
      title: t("categories.devOps"),
      tools: [
        { name: "Docker", logo: "/images/tech/docker.svg" },
        { name: "Kubernetes", logo: "/images/tech/kubernetes.svg" },
        { name: "Jenkins", logo: "/images/tech/jenkins.svg" },
        { name: "AWS", logo: "/images/tech/aws.svg" },
        { name: "GitHub Actions", logo: "/images/tech/github.svg" },
      ],
    },
  ];

  return (
    <section id="tech-stack" className="py-16 md:py-24">
      <div className="flex flex-col items-center mb-16">
        <div className="h-1 w-16 bg-gradient-to-r from-pink-500 to-purple-800 rounded-full mb-6" />
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white">
          {t("title")}
        </h2>
      </div>

      <div className="space-y-12">
        {techStacks.map((stack) => (
          <div key={stack.id}>
            <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-6">
              {stack.title}
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6">
              {stack.tools.map((tool) => (
                <div
                  key={tool.name}
                  className="flex flex-col items-center bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700 hover:shadow-md transition-shadow"
                >
                  <div className="w-12 h-12 mb-3 flex items-center justify-center">
                    <div className="w-10 h-10 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center">
                      {/* Placeholder for actual logos */}
                      <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
                        {tool.name.substring(0, 2)}
                      </span>
                    </div>
                  </div>
                  <span className="text-sm text-gray-700 dark:text-gray-300 font-medium">
                    {tool.name}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
} 