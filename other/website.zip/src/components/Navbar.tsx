"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { useLanguage } from "@/context/LanguageContext";

export default function Navbar() {
  const { locale, setLocale, messages } = useLanguage();
  const t = messages.nav || {}; // 获取导航栏相关翻译
  const tCompany = messages.company || {}; // 获取公司相关翻译
  const tCommon = messages.common || {}; // 获取通用相关翻译
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  // const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);


  // 切换语言
  const toggleLanguage = () => {
    setLocale(locale === "en" ? "zh" : "en");
  };
  
  // 处理挂载状态
  useEffect(() => {
    setMounted(true);
  }, []);

  // 处理滚动检测
  // useEffect(() => {
  //   const handleScroll = () => {
  //     if (window.scrollY > 10) {
  //       setIsScrolled(true);
  //     } else {
  //       setIsScrolled(false);
  //     }
  //   };

  //   window.addEventListener("scroll", handleScroll);
  //   return () => window.removeEventListener("scroll", handleScroll);
  // }, []);

  // 导航项
  const navItems = [
    { key: "aboutUs", label: t.aboutUs, href: "#about-us" },
    { key: "services", label: t.services, href: "#services" },
    { key: "caseStudies", label: t.caseStudies, href: "#case-studies" },
    { key: "team", label: t.team, href: "#team" },
    { key: "howItWorks", label: t.howItWorks, href: "#how-it-works" },
    { key: "hire", label: t.hire, href: "#hire" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 backdrop-blur-sm shadow-md
         ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link 
            href="/"
            className="flex items-center text-2xl font-bold bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-transparent bg-clip-text"
          >
            <Image 
              src="/logo.jpg" 
              alt="Logo" 
              width={32} 
              height={32} 
              className="h-8 w-auto mr-2 rounded" 
              priority
            />
            {tCompany.name}
          </Link>

          {/* Mobile menu button */}
          <button
            className="md:hidden"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              className="w-6 h-6"
            >
              {isMobileMenuOpen ? (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              ) : (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              )}
            </svg>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <Link
                key={item.key}
                href={item.href}
                className={`hover:text-purple-600 transition-colors text-base font-medium ${theme === 'dark' ? 'text-gray-300 hover:text-purple-400' : 'text-gray-700'}`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Actions */}
          <div className="hidden md:flex items-center gap-3">
            {/* Theme Toggle */}
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800"
              aria-label="切换主题"
            >
              {!mounted ? (
                <Moon className="h-5 w-5 text-gray-700" />
              ) : theme === "dark" ? (
                <Sun className="h-5 w-5 text-yellow-400" />
              ) : (
                <Moon className="h-5 w-5 text-gray-700" />
              )}
            </button>

            {/* Language Switch */}
            <button
              onClick={toggleLanguage}
              className={`hover:text-purple-600 transition-colors text-sm font-medium ${theme === 'dark' ? 'text-gray-300 hover:text-purple-400' : 'text-gray-700'}`}
            >
              {t.switchLanguage || (locale === "en" ? "中文" : "English")}
            </button>

            {/* Contact button */}
            <Link
              href="#contact"
              className="bg-gradient-to-r from-purple-600 to-indigo-700 hover:from-purple-700 hover:to-indigo-800 text-white font-medium py-2 px-4 rounded-md transition-colors"
            >
              {t.contactUs}
            </Link>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className={`md:hidden py-4 border-t ${theme === 'dark' ? 'border-gray-800' : 'border-gray-200'}`}>
            <nav className="flex flex-col gap-4">
              {navItems.map((item) => (
                <Link
                  key={item.key}
                  href={item.href}
                  className={`hover:text-purple-600 transition-colors text-base font-medium ${theme === 'dark' ? 'text-gray-300 hover:text-purple-400' : 'text-gray-700'}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              <Link
                href="#contact"
                className="text-purple-600 dark:text-purple-400 font-medium"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {t.contactUs || "Contact us"}
              </Link>
              <div className={`flex items-center justify-between mt-4 pt-4 border-t ${theme === 'dark' ? 'border-gray-800' : 'border-gray-200'}`}>
                <button
                  onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                  className={`flex items-center gap-2 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}
                >
                  {!mounted ? (
                    <>
                      <Moon className="h-5 w-5" />
                      <span>{tCommon.loading || "加载中..."}</span>
                    </>
                  ) : theme === "dark" ? (
                    <>
                      <Sun className="h-5 w-5 text-yellow-400" />
                      <span>切换到亮色</span>
                    </>
                  ) : (
                    <>
                      <Moon className="h-5 w-5" />
                      <span>切换到暗色</span>
                    </>
                  )}
                </button>
                <button
                  onClick={toggleLanguage}
                  className={`hover:text-purple-600 transition-colors text-sm font-medium ${theme === 'dark' ? 'text-gray-300 hover:text-purple-400' : 'text-gray-700'}`}
                >
                  {t.switchLanguage || (locale === "en" ? "中文" : "English")}
                </button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
} 