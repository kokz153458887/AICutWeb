"use client";

import { useTranslations } from "next-intl";

export default function CtaSection() {
  const t = useTranslations("cta");

  return (
    <section className="py-16 md:py-24">
      <div className="rounded-3xl bg-gradient-to-br from-purple-600 to-indigo-700 overflow-hidden relative">
        <div className="absolute inset-0 opacity-10">
          <svg
            width="100%"
            height="100%"
            viewBox="0 0 100 100"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <pattern
                id="grid"
                width="10"
                height="10"
                patternUnits="userSpaceOnUse"
              >
                <path
                  d="M 10 0 L 0 0 0 10"
                  fill="none"
                  stroke="white"
                  strokeWidth="0.5"
                />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        <div className="relative z-10 py-12 md:py-20 px-8 md:px-12 text-center">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 max-w-3xl mx-auto">
            {t("title")}
          </h2>
          <button className="bg-white text-purple-700 hover:bg-gray-100 font-semibold py-3 px-8 rounded-md transition-colors shadow-lg">
            {t("button")}
          </button>
        </div>
      </div>
    </section>
  );
} 