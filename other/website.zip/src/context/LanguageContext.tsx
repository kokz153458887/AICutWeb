"use client";

import React, { createContext, useState, useContext, useEffect } from 'react';
import { IntlProvider } from 'next-intl';

// 语言类型
type Locale = 'en' | 'zh';

// 消息类型
type Messages = Record<string, Record<string, string>>;

// 语言上下文类型
interface LanguageContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  messages: Messages;
}

// 创建上下文
const LanguageContext = createContext<LanguageContextType | null>(null);

// 自定义hook，用于在组件中使用语言上下文
export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

// 语言提供者组件
export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 获取浏览器语言偏好
  const getBrowserLocale = (): Locale => {
    if (typeof window !== 'undefined') {
      const savedLocale = localStorage.getItem('locale') as Locale;
      if (savedLocale) return savedLocale;

      const browserLang = navigator.language.startsWith('zh') ? 'zh' : 'en';
      return browserLang as Locale;
    }
    return 'en'; // 默认为英文
  };

  // 状态
  const [locale, setLocaleState] = useState<Locale>('en');
  const [messages, setMessages] = useState<Messages>({});
  const [loading, setLoading] = useState(true);

  // 设置语言
  const setLocale = (newLocale: Locale) => {
    localStorage.setItem('locale', newLocale);
    setLocaleState(newLocale);
    loadMessages(newLocale);
  };

  // 加载语言文件
  const loadMessages = async (locale: Locale) => {
    try {
      const messages = (await import(`../messages/${locale}.json`)).default as Messages;
      setMessages(messages);
      setLoading(false);
    } catch (error) {
      console.error(`Error loading messages for locale ${locale}:`, error);
      // 如果加载失败，回退到英文
      if (locale !== 'en') {
        setLocaleState('en');
        loadMessages('en');
      }
    }
  };

  // 初始化
  useEffect(() => {
    const initialLocale = getBrowserLocale();
    setLocaleState(initialLocale);
    loadMessages(initialLocale);
  }, []);

  // 如果正在加载，显示加载状态
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <LanguageContext.Provider value={{ locale, setLocale, messages }}>
      <IntlProvider locale={locale} messages={messages}>
        {children}
      </IntlProvider>
    </LanguageContext.Provider>
  );
};