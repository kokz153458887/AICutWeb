"use client";

import Image from "next/image";
import { useLanguage } from "@/context/LanguageContext";
import logger from "@/utils/logger";

interface CardProps {
  title: string;
  description: string | string[];
  image: string;
}

function Card({
  title,
  description,
  image,
}: CardProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-gray-100 dark:border-gray-700">
      <div className="relative h-48 bg-gradient-to-r from-purple-100 to-indigo-100 dark:from-purple-800/20 dark:to-indigo-800/20 flex items-center justify-center">
        <Image
          src={image}
          alt={title}
          width={400}
          height={300}
          className="object-cover h-full w-full"
          priority
        />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3 line-clamp-2">
          {title}
        </h3>
        <p className="text-gray-600 dark:text-gray-600 mb-4 line-clamp-3">
          {Array.isArray(description) ? (
            <ul className="list-disc pl-5">
              {description.map((item, index) => (
                <li key={index} className="mb-1 list-none">{item}</li>
              ))}
            </ul>
          ) : (
            description
          )}
        </p>
      </div>
    </div>
  );
}

export default function AboutUs() {
  const { messages } = useLanguage();
  const t = messages.aboutUs || {};
  const vision = t.vision as unknown as Record<string, string>;
  const mission = t.mission as unknown as Record<string, string>;
  const values = t.values as unknown as Record<string, string>;
  // const coreStrategy = t.coreStrategy as unknown as Record<string, string>;

  const cardItems = [
    { 
      ...vision,
      image: "/images/about/vision.png"
    },
    {
      ...mission,
      image: "/images/about/mission.png"
    },
    {
      ...values,
      image: "/images/about/values.png"
    },
    // {
    //   ...coreStrategy
    // },
  ];

  logger.debug("cardItems:", cardItems)

  return (
    <section id="about-us" className="py-16 md:py-24">
      <div className="space-y-8">
        <div className="flex items-center gap-4">
          <div className="h-1 w-16 bg-gradient-to-r from-pink-500 to-purple-800 rounded-full" />
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-black dark:text-white">
            {t.title}
          </h2>
        </div>
        <p className="text-lg text-gray-700 dark:text-gray-400 max-w-3xl">
          {t.description}
        </p>
      </div>

      {/* 愿景、使命、价值观和核心战略 */}
      <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
        {cardItems.map((item, index) => (
          <Card key={index} {...(item as unknown as CardProps)} />
        ))}
      </div>

      {/* <div className="mt-16 relative">
        <div className="bg-white dark:bg-gray-800 rounded-xl p-2 md:p-4 aspect-video relative overflow-hidden shadow-md">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="rounded-full bg-white/40 dark:bg-black/40 w-20 h-20 flex items-center justify-center cursor-pointer">
              <div className="rounded-full bg-purple-600 w-16 h-16 flex items-center justify-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="white"
                  className="w-8 h-8"
                >
                  <path d="M8 5.14v14l11-7-11-7z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div> */}
    </section>
  );
} 