"use client";

import { useState } from 'react';
import { ChevronLeft, ChevronRight, Star } from "lucide-react";
import { useLanguage } from '@/context/LanguageContext';
import logger from '@/utils/logger';

interface TestimonialProps {
  id: number;
  text: string;
  name: string;
  company: string;
}

function TestimonialCard({ text, name, company }: TestimonialProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-md border border-gray-100 dark:border-gray-700">
      <div className="flex gap-1 mb-4">
        {[...Array(5)].map((_, i) => (
          <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
        ))}
      </div>
      <p className="text-gray-700 dark:text-gray-300 mb-6">&ldquo;{text}&rdquo;</p>
      <div className="flex items-center gap-4">
        <div className="relative w-12 h-12 rounded-full overflow-hidden bg-gradient-to-r from-purple-300 to-indigo-300 dark:from-purple-600 dark:to-indigo-600 flex items-center justify-center">
          <span className="text-white font-medium text-sm">{name.substring(0, 2)}</span>
        </div>
        <div>
          <h4 className="font-semibold text-gray-900 dark:text-white">{name}</h4>
          <p className="text-sm text-gray-500 dark:text-gray-400">{company}</p>
        </div>
      </div>
    </div>
  );
}

export default function Testimonials() {
  const { messages } = useLanguage();
  const t = messages.testimonials || {};
  const examples = t.examples as unknown as [Record<string, string>];
  const [currentIndex, setCurrentIndex] = useState(0);

  logger.debug("examples:", examples);
  const testimonials:TestimonialProps[] = examples.map((example, index) => ({
    id: index + 1,
    ...example,
  })) as TestimonialProps[];

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="py-16 md:py-24 bg-gray-50 dark:bg-gray-900 rounded-3xl">
      <div className="flex flex-col items-center mb-12">
        <div className="h-1 w-16 bg-gradient-to-r from-pink-500 to-purple-800 rounded-full mb-6" />
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white">
          {t.title}
        </h2>
      </div>

      <div className="relative max-w-3xl mx-auto">
        <div className="overflow-hidden">
          <div
            className="flex transition-transform duration-300 ease-in-out"
            style={{ transform: `translateX(-${currentIndex * 100}%)` }}
          >
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="w-full flex-shrink-0 px-4">
                <TestimonialCard
                  {...testimonial}
                />
              </div>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-center mt-8 gap-4">
          <button
            onClick={prevTestimonial}
            className="p-2 rounded-full bg-white dark:bg-gray-800 shadow-md border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="flex gap-2">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentIndex(i)}
                className={`w-3 h-3 rounded-full ${
                  i === currentIndex
                    ? "bg-purple-600"
                    : "bg-gray-300 dark:bg-gray-700"
                }`}
              />
            ))}
          </div>
          <button
            onClick={nextTestimonial}
            className="p-2 rounded-full bg-white dark:bg-gray-800 shadow-md border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </section>
  );
} 