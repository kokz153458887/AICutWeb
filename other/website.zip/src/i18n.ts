import {getRequestConfig} from 'next-intl/server';
import {notFound} from 'next/navigation';
import {defaultLocale, locales} from './config';

export default getRequestConfig(async ({locale}) => {
  // Validate that the incoming `locale` parameter is valid
  if (!locales.includes(locale as string)) {
    notFound();
  }

  const typedLocale: string = locale as string;

  return {
    messages: (await import(`../messages/${typedLocale}.json`)).default,
    locale: typedLocale
  };
});

export function getLocale(headers: Headers): string {
  // 获取Accept-Language头部
  const acceptLanguage = headers.get('Accept-Language') || '';
  
  // 如果以zh开头，返回中文，否则返回英文
  if (acceptLanguage.startsWith('en')) {
    return 'en';
  }
  
  return defaultLocale;
} 