/**
 * 日志工具类
 * 对console进行封装，提供不同级别的日志输出
 */

// 日志级别枚举
enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
  NONE = 4
}

// 当前环境的日志级别
const currentLogLevel = process.env.NODE_ENV === 'production' 
  ? LogLevel.ERROR  // 生产环境只显示错误
  : LogLevel.DEBUG; // 开发环境显示所有日志
console.log("currentLogLevel:", currentLogLevel);
// 颜色样式配置
const styles = {
  debug: 'color: #7986cb; font-weight: bold',
  info: 'color: #4caf50; font-weight: bold',
  warn: 'color: #ff9800; font-weight: bold',
  error: 'color: #f44336; font-weight: bold',
  time: 'color: #9c27b0; font-weight: bold'
};

/**
 * 日志类
 */
class Logger {
  private prefix: string;

  /**
   * 构造函数
   * @param prefix 日志前缀
   */
  constructor(prefix: string = '') {
    this.prefix = prefix ? `[${prefix}]` : '';
  }

  /**
   * 调试日志
   * @param args 日志参数
   */
  debug(...args: unknown[]): void {
    if (currentLogLevel <= LogLevel.DEBUG) {
      console.debug(`%c${this.getTimeString()} DEBUG ${this.prefix}`, styles.debug, ...args);
    }
  }

  /**
   * 信息日志
   * @param args 日志参数
   */
  info(...args: unknown[]): void {
    if (currentLogLevel <= LogLevel.INFO) {
      console.info(`%c${this.getTimeString()} INFO ${this.prefix}`, styles.info, ...args);
    }
  }

  /**
   * 警告日志
   * @param args 日志参数
   */
  warn(...args: unknown[]): void {
    if (currentLogLevel <= LogLevel.WARN) {
      console.warn(`%c${this.getTimeString()} WARN ${this.prefix}`, styles.warn, ...args);
    }
  }

  /**
   * 错误日志
   * @param args 日志参数
   */
  error(...args: unknown[]): void {
    if (currentLogLevel <= LogLevel.ERROR) {
      console.error(`%c${this.getTimeString()} ERROR ${this.prefix}`, styles.error, ...args);
    }
  }

  /**
   * 计时开始
   * @param label 计时标签
   */
  time(label: string): void {
    if (currentLogLevel <= LogLevel.DEBUG) {
      console.time(label);
    }
  }

  /**
   * 计时结束
   * @param label 计时标签
   */
  timeEnd(label: string): void {
    if (currentLogLevel <= LogLevel.DEBUG) {
      console.timeEnd(label);
    }
  }

  /**
   * 获取当前时间字符串
   * @returns 格式化的时间字符串
   */
  private getTimeString(): string {
    const now = new Date();
    return `[${now.toLocaleTimeString('zh-CN', { hour12: false })}:${now.getMilliseconds().toString().padStart(3, '0')}]`;
  }
}

// 创建默认日志实例
const logger = new Logger();

// 导出日志工具
export default logger;

// 导出Logger类，允许创建带有特定前缀的日志实例
export { Logger, LogLevel };
