"use client";

import { useTranslations } from "next-intl";
import { ArrowRight } from "lucide-react";

interface CaseStudyProps {
  title: string;
  description: string;
  cta: string;
  bgColor: string;
}

function CaseStudy({ title, description, cta, bgColor }: CaseStudyProps) {
  return (
    <div
      className={`rounded-2xl overflow-hidden grid grid-cols-1 md:grid-cols-2 ${bgColor}`}
    >
      <div className="p-6 md:p-10 flex flex-col justify-between">
        <div>
          <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
            {title}
          </h3>
          <p className="text-gray-600 dark:text-gray-300 mb-6 line-clamp-6">
            {description}
          </p>
        </div>
        <div className="flex items-center gap-2 text-purple-600 dark:text-purple-400 font-medium cursor-pointer group">
          <span>{cta}</span>
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
      <div className="relative h-64 md:h-auto">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-100 to-indigo-100 dark:from-purple-900/20 dark:to-indigo-900/20 flex items-center justify-center">
          <span className="text-gray-600 dark:text-gray-300 font-medium">{title}</span>
        </div>
      </div>
    </div>
  );
}

export default function CaseStudies() {
  const t = useTranslations("caseStudies");
  
  const caseStudies = [
    {
      id: 1,
      title: t("example.title"),
      description: t("example.description"),
      cta: t("example.cta"),
      image: "/images/case-study-1.jpg",
      bgColor: "bg-red-50 dark:bg-red-900/20",
    },
    {
      id: 2,
      title: t("example.title"),
      description: t("example.description"),
      cta: t("example.cta"),
      image: "/images/case-study-2.jpg",
      bgColor: "bg-green-50 dark:bg-green-900/20",
    },
    {
      id: 3,
      title: t("example.title"),
      description: t("example.description"),
      cta: t("example.cta"),
      image: "/images/case-study-3.jpg",
      bgColor: "bg-blue-50 dark:bg-blue-900/20",
    },
  ];

  return (
    <section id="case-studies" className="py-16 md:py-24">
      <div className="mb-12">
        <div className="flex flex-col items-center">
          <div className="h-1 w-16 bg-gradient-to-r from-pink-500 to-purple-800 rounded-full mb-6" />
          <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white">
            {t("title")}
          </h2>
        </div>
      </div>

      <div className="space-y-8">
        {caseStudies.map((study) => (
          <CaseStudy
            key={study.id}
            title={study.title}
            description={study.description}
            cta={study.cta}
            bgColor={study.bgColor}
          />
        ))}
      </div>

      <div className="mt-12 flex justify-center">
        <button className="flex items-center gap-2 text-purple-600 dark:text-purple-400 font-medium group">
          <span>{t("readMoreCta")}</span>
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </section>
  );
} 