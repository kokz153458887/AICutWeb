"use client";

import Image from "next/image";
import { useLanguage } from "@/context/LanguageContext";

export default function Hero() {
  const { messages } = useLanguage();
  const t = messages.hero || {};

  return (
    <section className="py-20 md:py-28 lg:py-36">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="space-y-8 ">
          {Array.isArray(t.title) ? (
            t.title.map((title, index) => (
              <h1 key={index} className="text-2xl md:text-3xl lg:text-4xl font-extrabold text-black dark:text-white leading-tight">
                {title}
              </h1>
            ))
          ) : ( 
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-black dark:text-white leading-tight">
            {t.title}
          </h1>
          )}
          {/* <p className="text-2xl text-gray-700 dark:text-gray-400">
            {t.subtitle}
          </p> */}
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 px-6 rounded-md transition-colors">
            {t.cta}
          </button>
        </div>
        <div className="relative h-80 md:h-96 lg:h-[400px]">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-50 to-indigo-100 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-lg" />
          <div className="absolute inset-0 flex items-center justify-center">
            {/* <div className="w-64 h-64 bg-gradient-to-r from-indigo-300 to-purple-300 dark:from-indigo-600 dark:to-purple-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-2xl">CodeDream</span>
            </div> */}
            
              <Image
                src="/images/home/create-value-background1.png"
                alt="Web Development"
                width={500}
                height={400}
                className="object-cover h-full w-full rounded-lg"
                priority
              />
            
          </div>
        </div>
      </div>
    </section>
  );
} 