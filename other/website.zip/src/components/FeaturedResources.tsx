"use client";

import { useTranslations } from "next-intl";
import { ArrowRight } from "lucide-react";

interface BlogCardProps {
  title: string;
  summary: string;
  date: string;
  readTime: string;
  category: string;
}

function BlogCard({
  title,
  summary,
  date,
  readTime,
  category,
}: BlogCardProps) {
  const t = useTranslations("featured");
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-gray-100 dark:border-gray-700">
      <div className="relative h-48 bg-gradient-to-r from-purple-100 to-indigo-100 dark:from-purple-800/20 dark:to-indigo-800/20 flex items-center justify-center">
        <span className="text-gray-600 dark:text-gray-300 font-medium">{category}</span>
      </div>
      <div className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-xs font-medium text-purple-600 dark:text-purple-400 bg-purple-100 dark:bg-purple-900/20 px-2 py-0.5 rounded-full">
            {category}
          </span>
          <span className="text-xs text-gray-500 dark:text-gray-400">
            {date} · {readTime}
          </span>
        </div>
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3 line-clamp-2">
          {title}xxx
        </h3>
        <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
          {summary}
        </p>
        <div className="flex items-center gap-2 text-purple-600 dark:text-purple-400 font-medium cursor-pointer group">
          <span>{t("readMore")}</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </div>
  );
}

export default function FeaturedResources() {
  const t = useTranslations("featured");

  const blogs = [
    {
      id: 1,
      title: "How to build a successful mobile app in 2023",
      summary:
        "Learn the essential steps to create a successful mobile application that users will love and engage with.",
      date: "Apr 12, 2023",
      readTime: "5 min read",
      category: "Mobile Development",
    },
    {
      id: 2,
      title: "The complete guide to modern web development",
      summary:
        "Discover the latest technologies, best practices, and frameworks for creating modern web applications.",
      date: "Mar 28, 2023",
      readTime: "8 min read",
      category: "Web Development",
    },
    {
      id: 3,
      title: "Building scalable backend services with microservices",
      summary:
        "Explore how microservices architecture can help you build more scalable and maintainable backend systems.",
      date: "Feb 15, 2023",
      readTime: "10 min read",
      category: "Backend",
    },
  ];

  return (
    <section id="blog" className="py-16 md:py-24">
      <div className="flex flex-col items-center mb-12">
        <div className="h-1 w-16 bg-gradient-to-r from-pink-500 to-purple-800 rounded-full mb-6" />
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white">
          {t("title")}
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {blogs.map((blog) => (
          <BlogCard
            key={blog.id}
            title={blog.title}
            summary={blog.summary}
            date={blog.date}
            readTime={blog.readTime}
            category={blog.category}
          />
        ))}
      </div>
    </section>
  );
} 