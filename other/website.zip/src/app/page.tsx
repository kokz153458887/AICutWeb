"use client";

import { useEffect, useState } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import AboutUs from '@/components/AboutUs';
import Services from '@/components/Services';
import CaseStudies from '@/components/CaseStudies';
import Approach from '@/components/Approach';
import Testimonials from '@/components/Testimonials';
import DevelopmentProcess from '@/components/DevelopmentProcess';
import TechStack from '@/components/TechStack';
import Team from '@/components/Team';
import CtaSection from '@/components/CtaSection';
import Footer from '@/components/Footer';

// 语言上下文
import { LanguageProvider } from '@/context/LanguageContext';

export default function Home() {
  const [mounted, setMounted] = useState(false);

  // 等待客户端渲染完成
  useEffect(() => {
    setMounted(true);
  }, []);

  // 在服务器端渲染和客户端hydration阶段显示加载状态
  if (!mounted) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
      </div>
    );
  }
  
  return (
    <LanguageProvider>
      <main className="min-h-screen">
        <Navbar />
        <div className="section-hero">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <Hero />
          </div>
        </div>
        <div className="section-about">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <AboutUs />
          </div>
        </div>
        <div className="section-services">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <Services />
          </div>
        </div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <CaseStudies />
          <Testimonials />
          <Team />
          <Approach />
          <DevelopmentProcess />
          <TechStack />
          <CtaSection />
        </div>
        <Footer />
      </main>
    </LanguageProvider>
  );
}
